# Style guide

**Font:** `Arial, sans-serif`

## Colors

| Name | Color | Used for |
|---|---|---|
| Page background | `#f1f5f9` | behind everything, and the info boxes |
| Dark navy | `#14213d` | sidebar, picture squares, main text |
| Lighter navy | `#22325a` | the "Did you know?" box |
| Purple | `#6366f1` | logo circle, active link, button, tags text, chips text |
| Soft purple | `#eef0ff` | banner, tags |
| White | `#ffffff` | rows, chips, "Details" button text |
| Sidebar text | `#aab4cf` | menu links, tip paragraph |
| Gray text | `#5b6585` | banner paragraph |
| Light gray text | `#7a84a3` | small labels, footer |
| Number gray | `#c7cbe8` | 01, 02, 03... |
| Border | `#e2e8f0` | border of each row |

## Sidebar

| Part | Values |
|---|---|
| Sidebar | width 280px, padding 32px 24px, gap 36px |
| Brand | gap 12px, text 18px bold, white |
| Logo circle | 42 x 42px, round, letter 20px |
| Menu | gap 6px |
| Menu link | padding 14px 16px, radius 10px, text 16px |
| Active link | purple background, white bold text |
| Tip box | padding 20px, radius 16px, gap 10px |
| Tip title | 16px, white. Tip text 14px, line-height 1.5 |

## Main area

| Part | Values |
|---|---|
| Main | width 1160px, padding 48px 56px, gap 32px |
| Banner | padding 40px 48px, radius 24px |
| Banner text block | width 600px, gap 16px |
| Banner heading | 44px, bold, line-height 1.15 |
| Banner paragraph | 18px, line-height 1.5 |
| Chips | gap 12px. Each: padding 12px 18px, radius 12px, 15px bold |
| Banner picture | 220 x 220px, radius 20px |
| "All planets" title | 26px |
| List | gap 16px |

## Planet row

| Part | Values |
|---|---|
| Row | padding 20px, border 1px, radius 20px, gap 16px |
| Number | width 60px, 28px bold |
| Picture square | 140 x 140px, radius 16px |
| Planet image | 100 x 100px |
| Name block | width 200px, gap 10px |
| Planet name | 26px |
| Tag | padding 6px 12px, radius 20px, 13px bold |
| Info row | gap 10px |
| Info box | width 130px, padding 14px, radius 12px, gap 6px |
| Info label | 12px |
| Info value | 16px bold |
| Button | width 120px, padding 14px, radius 12px, no border, 14px bold |

## Footer

padding 20px, text 14px, centered.

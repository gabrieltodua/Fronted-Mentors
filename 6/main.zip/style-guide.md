# Style guide

**Font:** `Arial, sans-serif`

## Colors

| Name | Color | Used for |
|---|---|---|
| Page background | `#f5f7ff` | the whole page |
| White | `#ffffff` | header, cards, footer, chips |
| Ink | `#1e1b4b` | text, headings, the dark chip |
| Gray text | `#5f6b85` | nav links, paragraphs |
| Line | `#e3e7f5` | borders of header, cards, chips, footer |
| Purple | `#7c3aed` | logo icon, buttons, "explained", footer title |
| Soft purple | `#ede9fe` | hero label background |

### Card top colors

| Group | Color |
|---|---|
| Web | `#ffedd5` |
| Apps | `#dbeafe` |
| Systems | `#fce7f3` |
| Data | `#d1fae5` |

## Header

| Part | Values |
|---|---|
| Header | padding 20px 120px, border-bottom 1px |
| Brand | gap 12px |
| Icon | 42 x 42px, radius 12px, 16px bold |
| Logo | 24px, bold |
| Nav | gap 36px |
| Links | 16px |
| Button | padding 11px 24px, radius 24px, 15px bold, no border |

## Hero

| Part | Values |
|---|---|
| Hero | padding 64px 120px 48px, gap 20px |
| Label | padding 8px 16px, radius 20px, 13px bold |
| Heading | 64px, centered |
| Paragraph | width 620px, 20px, line-height 1.6, centered |
| Chips | gap 12px, 8px space above |
| Chip | padding 10px 22px, border 2px, radius 24px, 15px bold |
| Dark chip | background and border `#1e1b4b`, white text |

## Languages area

| Part | Values |
|---|---|
| Section | padding 24px 120px 90px |
| Title row | 28px space below |
| Title | 34px |
| Small text | 15px |
| Grid | 4 columns, gap 24px |

## Card

| Part | Values |
|---|---|
| Card | border 1px, radius 24px |
| Card top | height 150px |
| Logo | 96 x 96px |
| Card body | padding 22px, gap 10px |
| Name | 26px |
| Text | 15px, line-height 1.6 |

## Footer

| Part | Values |
|---|---|
| Footer | padding 36px 120px, border-top 1px, gap 8px |
| Title | 20px, bold |
| Text | 15px |

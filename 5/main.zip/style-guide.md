# Style guide

**Fonts**
- Normal text: `Arial, sans-serif`
- Headings (`h1`, `h2`, `h3`) and the logo: `Georgia, serif`

## Colors

| Name | Color | Used for |
|---|---|---|
| Brown | `#3a1d12` | text, headings, nav links, footer background |
| Tomato red | `#d62828` | logo, main buttons, prices |
| Cream | `#fff4e0` | page background, second button background |
| White | `#ffffff` | menu section background |
| Basil green | `#2d6a4f` | the small hero label |
| Soft brown | `#7a5a48` | paragraphs |
| Dashed line | `#dcc7a8` | lines between menu items |
| Yellow | `#f7b538` | footer titles |
| Footer text | `#e8d5bd` | footer paragraphs |

## Header

| Part | Values |
|---|---|
| Header | padding 26px 120px |
| Left menu | width 400px, gap 36px |
| Logo | width 400px, 34px, bold, centered |
| Right menu | width 400px, gap 36px, pushed to the right |
| Links | 16px, bold |
| "Order now" button | padding 12px 26px, radius 30px, 15px bold, no border |

## Hero

| Part | Values |
|---|---|
| Hero | padding 50px top, 120px sides, 80px bottom |
| Pizza picture | 500 x 500px |
| Text block | width 580px, gap 24px |
| Label | 15px, bold |
| Heading | 72px, line-height 1.05 |
| Paragraph | 19px, line-height 1.7 |
| Buttons | gap 16px |
| Main button | padding 18px 34px, radius 40px, 16px bold, no border |
| Second button | padding 16px 34px, radius 40px, 16px bold, border 2px brown |

## Menu

| Part | Values |
|---|---|
| Section | padding 90px 120px, gap 40px |
| Title block | gap 12px |
| Title "Our menu" | 56px |
| Small text | 19px |
| List | width 800px |
| Each item | padding 26px 0, border-bottom 2px dashed |
| Text block | width 600px, gap 8px |
| Pizza name | 28px |
| Description | 16px |
| Price | 32px, bold |

## Footer

| Part | Values |
|---|---|
| Footer | padding 56px 120px |
| Each column | width 300px, gap 10px |
| Text | 16px, line-height 1.5 |
| First line (title) | 19px, bold |

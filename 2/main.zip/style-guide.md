# Style guide

Use these values to match the design.

## Colors

| Name | Color | Used for |
|---|---|---|
| Page background | `#f6f7fb` | the whole page behind everything |
| White | `#ffffff` | header, cards, stat boxes, footer |
| Main text | `#0f172a` | headings and most text |
| Medium text | `#475569` | the hero paragraph |
| Gray text | `#64748b` | stat labels, sub-title, player labels |
| Light gray text | `#94a3b8` | the small note, fact labels, footer text |
| Primary (indigo) | `#4f46e5` | buttons, big numbers, highlights |
| Primary hover | `#4338ca` | button hover |
| Soft indigo | `#eef2ff` | hero panel, tags, "View game" button, active link |
| Border | `#e5e7ef` | borders of the header, cards, stat boxes |
| Divider | `#eef0f6` | thin lines inside the card |
| Card hover border | `#c7d2fe` | card border on hover |
| Second button border | `#d5dbe8` | "Watch trailer" border |

### Picture tile colors

| Class | Color |
|---|---|
| `.t-green` | `#1fb641` |
| `.t-blue` | `#3355ff` |
| `.t-coral` | `#ff7a59` |
| `.t-sky` | `#2d9cdb` |
| `.t-navy` | `#283a81` |
| `.t-royal` | `#1e4fd8` |
| `.t-dark` | `#1f2937` |

## Font

```
font-family: Inter, -apple-system, "Segoe UI", Arial, sans-serif;
```

(If Inter is not installed, your computer uses the next one. That is fine.)

## Text sizes

| Element | Size | Weight | Other |
|---|---|---|---|
| Brand name "POPULAR GAME STUDIO" | 18px | 800 | letter-spacing 0.5px |
| Brand "P" | 20px | normal | white on indigo |
| Navigation links | 15px | 600 | |
| Join us button | 15px | 700 | |
| Hero label "THE GAME HUB" | 13px | 700 | letter-spacing 1px |
| Hero heading | 54px | bold | line-height 1.1, letter-spacing -1px |
| Hero paragraph | 18px | normal | line-height 1.6 |
| Hero buttons | 16px | 700 | |
| Stat number | 32px | 800 | no line breaks (`white-space: nowrap`) |
| Stat label | 15px | normal | |
| Section title "Popular games" | 34px | bold | letter-spacing -0.5px |
| Section sub-title | 16px | normal | |
| Small note | 13px | normal | |
| Number badge (01, 02...) | 13px | 800 | |
| Tag (genre) | 12px | 700 | |
| Card title | 20px | bold | line-height 1.3 |
| Big player number | 32px | 800 | letter-spacing -0.5px |
| Player label | 12px | normal | |
| Fact rows | 13px | normal | values are weight 600 |
| "View game" button | 14px | 700 | |
| Footer text | 14px | normal | |

## Sizes and spacing

| Part | Values |
|---|---|
| Header | padding 18px top and bottom, 120px left and right. Bottom border 1px |
| Brand icon | 40 x 40px, radius 12px. Gap to the name: 12px |
| Navigation | gap 8px. Each link: padding 10px 18px, radius 10px |
| Join us button | padding 12px 26px, radius 10px |
| Hero panel | width 1200px, centered. Margin 48px top, 28px bottom. Padding 64px 72px. Radius 32px |
| Hero text block | width 560px. Gap between items 22px |
| Hero label | padding 8px 16px, fully rounded (radius 20px) |
| Hero buttons | gap 14px. Padding 16px 32px, radius 12px |
| Picture tiles | 190 x 190px, radius 28px, gap 18px. Second column moved down 28px |
| Small logo in a tile | 96 x 96px |
| Stat boxes | width 1200px total, centered, gap 24px. Padding 24px 28px, radius 20px, border 1px. Margin below: 64px |
| Section area | width 1200px, centered. Margin below: 90px |
| Section title row | space below it: 28px. Sub-title is 8px below the title |
| Card grid | 4 columns, gap 24px |
| Card | border 1px, radius 22px |
| Picture area | height 280px |
| Logo in a picture area | 124 x 124px (the GTA logo is 72% of the width) |
| Number badge | 14px from top and left. Padding 6px 12px, radius 20px |
| Text area | padding 22px, gap 14px |
| Tag | padding 6px 12px, radius 20px |
| Players block | padding 14px top and bottom. 1px lines above and below |
| Fact rows | gap 10px between rows |
| Small flag | 20px wide, radius 3px. Gap to the text: 7px |
| "View game" button | padding 13px, radius 12px |
| Footer | padding 30px, border-top 1px |

## Effects

| What | Effect |
|---|---|
| Shadow of the hero buttons and tiles | `0 8px 20px rgba(79, 70, 229, 0.3)` for the main button. Tiles: `0 14px 30px rgba(15, 23, 42, 0.15)` |
| Card hover | moves up 6px, shadow `0 18px 40px rgba(15, 23, 42, 0.12)`, border `#c7d2fe` |
| Main hero button hover | moves up 2px, color `#4338ca` |
| "View game" hover | background `#4f46e5`, text white |
| "Watch trailer" hover | border and text `#4f46e5` |
| Join us hover | background `#4338ca` |
| Navigation link hover | text `#0f172a`, background `#f1f5f9` |
| Number badge shadow | `0 4px 10px rgba(0, 0, 0, 0.15)` |
| Small flag outline | `0 0 0 1px rgba(0, 0, 0, 0.1)` |
| Transitions | 0.2s for buttons and links, 0.25s for cards |

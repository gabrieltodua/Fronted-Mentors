# Style guide

**Font:** `Arial, sans-serif`. Nothing is rounded in this design.

## Colors

| Name | Color | Used for |
|---|---|---|
| Black | `#0a0a0a` | header, hero, split right half, text, thick lines |
| Neon | `#d4ff3a` | logo, buttons, strip, split left half, footer, header line |
| Pink | `#ff4d8d` | hero label, trick numbers |
| Off-white | `#f4f4ee` | page background |
| White | `#ffffff` | hero heading, nav links, split heading, picture border |
| Light gray | `#a3a3a3` | hero paragraph, split paragraph |
| Dark gray | `#555555` | paragraphs on the light background |

## Header

| Part | Values |
|---|---|
| Header | padding 22px 120px, border-bottom 4px neon |
| Logo | 24px, bold |
| Nav | gap 36px |
| Nav links | 15px, bold |
| Join button | padding 12px 28px, 15px bold, no border |

## Hero

| Part | Values |
|---|---|
| Hero | padding 80px 120px |
| Text block | width 640px, gap 26px |
| Label | padding 8px 14px, 14px bold |
| Heading | 104px, line-height 1 |
| Paragraph | 20px, line-height 1.6 |
| Buttons | gap 16px |
| Main button | padding 18px 34px, 16px bold, no border |
| Second button | padding 16px 34px, 16px bold, border 3px white |
| Picture | 480 x 480px, border 6px white |

## Strip

| Part | Values |
|---|---|
| Strip | padding 22px 120px, border-bottom 4px black |
| Words | 30px, bold |

## Tricks

| Part | Values |
|---|---|
| Section | padding 100px 120px |
| Left text block | width 380px, gap 22px |
| Left heading | 58px, line-height 1.05 |
| Left paragraph | 18px, line-height 1.6 |
| List | width 720px, border-top 4px black |
| Each trick | padding 28px 0, border-bottom 4px black |
| Number | width 80px, 22px bold |
| Name | width 380px, 46px bold |
| Level | width 120px, padding 8px 0, border 3px black, 15px bold, centered |

## Split screen

| Part | Values |
|---|---|
| Each half | width 720px |
| Left half | padding 90px 120px, gap 8px |
| Big number | 220px, bold, line-height 1 |
| Small text | 24px, bold |
| Right half | padding 90px 120px 90px 90px, gap 24px |
| Heading | 56px, line-height 1.05 |
| Paragraph | 18px, line-height 1.6 |
| Button | same as the hero main button |

## Call to action

| Part | Values |
|---|---|
| Section | padding 100px 120px, gap 24px |
| Ramp picture | 600 x 240px |
| Heading | 96px, centered |
| Paragraph | width 600px, 20px, centered |
| Button | padding 20px 48px, 18px bold, no border |

## Footer

| Part | Values |
|---|---|
| Footer | padding 56px 120px 32px, gap 40px |
| Each column | width 300px, gap 10px |
| Text | 16px, line-height 1.5 |
| First line (title) | 18px, bold |
| Big word | 112px, bold, line-height 1 |

# Popular Game Studio: Frontend Challenge

Welcome! Your mission is to rebuild a real website using **only CSS**.

| | |
|---|---|
| **Level** | Junior+ (one step above beginner) |
| **Time** | About 3 to 5 hours |
| **Tools** | A code editor (VS Code) and Chrome |
| **Screen** | Desktop only. Make your browser window **1440 px wide**. No mobile version needed. |

---

## The mission

The HTML is already written for you in `index.html`. Right now it has no style at all, so it looks very plain.

Your job: write `style.css` so the page looks as close as possible to **`design/desktop-full.png`**.

## What you will practice

- `display: flex` in many places: rows, columns, centering, `space-between`, `gap`
- `display: grid` with columns (this one is new!)
- `position: relative` and `position: absolute` (the number badge on the pictures)
- `padding`, `margin`, `border`, `border-radius`, `box-shadow`
- `width`, `height`, and centering a block with `margin: 0 auto`
- `object-fit` for pictures (new!)
- `:hover` and `transition`
- `box-sizing: border-box`
- Using colors, fonts and sizes from a style guide

## What is in this folder

```
popular-game-studio-challenge/
├── README.md          <- you are here
├── style-guide.md     <- colors, fonts, sizes (read this second)
├── index.html         <- the HTML (already done, do not change)
├── style.css          <- YOUR WORK GOES HERE
├── images/            <- the 8 game pictures
├── flags/             <- 4 small flag pictures
└── design/            <- the design to copy
    ├── desktop-full.png          (the whole page)
    ├── closeup-header.png
    ├── closeup-hero.png
    ├── closeup-card-minecraft.png
    └── closeup-card-pubg.png
```

## Rules

1. Only edit `style.css`. Do not change the text or structure of `index.html`.
2. No frameworks and no copying code from other websites. Looking up properties on **MDN** is allowed (and smart!).
3. The design image is the truth. Zoom in on it. The close-up images show the small details.
4. Save and refresh your browser often. Small steps are easier than one big step.

## Tips before you start

- Open `index.html` in Chrome. Right-click anything and choose **Inspect** to see its box and styles.
- Not sure where a box starts and ends? Temporarily add `outline: 1px solid red;` to it.
- Work from the top of the page to the bottom, one section at a time.
- Keep the design image next to your browser and compare after every step.

---

## Step by step

### Step 1: Set up the page

**Goal:** a clean base for everything else.

Hints:
- Make every element include its padding and border in its size (`box-sizing`).
- Remove the default margin from `body` and from `p`, `h1`, `h2`, `h3`, `ul`.
- Remove the bullet points from lists.
- Give the `body` its background color, text color and font (see the style guide).

### Step 2: The header

**Goal:** a white bar with the logo on the left, links in the middle, and a button on the right.

Hints:
- One flex row with the three parts spread apart, all centered vertically.
- The "P" square: a colored box with rounded corners. Center the letter inside it (flex again!).
- The links are just padded boxes with rounded corners. The active one has a soft background.
- Remember the thin line under the header (`border-bottom`).

### Step 3: The hero (the big light panel)

**Goal:** text on the left, four colored picture tiles on the right.

Hints:
- The panel has a fixed width and is centered on the page.
- Inside, use flex to put the text block and the tiles side by side.
- The text block is a **column** of items with space between them (flex with a direction and a gap).
- The small "THE GAME HUB" label must NOT stretch to the full width. Look up `align-self`.
- The word "games" in the heading has its own color. It lives in a `<span>`.
- The tiles are a **grid with 2 columns**. Every second tile sits lower than the first. Look up `:nth-child` and `transform`.
- Two tiles hold a small logo in the middle, and one tile holds a picture that fills the whole tile (`object-fit`).

### Step 4: The three stat boxes

**Goal:** three equal white boxes in a row.

Hints:
- A flex row with a gap. Use `flex: 1` so the boxes share the width equally.
- Inside each box: the number and its label side by side, centered.

### Step 5: The section title

**Goal:** "Popular games" and its sub-title on the left, a small gray note on the right.

Hints:
- Flex with `space-between`. The right note sits at the **bottom** of the row (look at `align-items`).

### Step 6: The card grid

**Goal:** 8 equal cards, 4 per row.

Hints:
- The `.grid` is a CSS grid with 4 equal columns and a gap. (Try `repeat()` and `fr`.)
- Each card is a white box with a thin border and rounded corners. Make the picture's corners round too (`overflow`).
- Inside a card, stack the picture area and the text area vertically with flex.

### Step 7: The picture area of each card

**Goal:** a colored square with a logo, a number badge in the corner.

Hints:
- Give it a fixed height and center its content.
- The `.t-green`, `.t-blue`... classes are colored backgrounds. Each class needs its color (see the style guide).
- The number badge sits in the top-left corner. It needs `position: absolute`, and its parent needs `position: relative`.
- Logo pictures have a set size and should keep their shape (`object-fit: contain`).
- The `cover` pictures fill the whole area (`object-fit: cover`).
- On the Red Dead card, the picture is cropped to show the face and the title. Look up `object-position`.

### Step 8: The text area of each card

**Goal:** tag, title, big number, three fact rows, button at the bottom.

Hints:
- The text area is a flex column with a gap and padding.
- The tag must be only as wide as its text (`align-self` again).
- The "players" block has a thin line above and below it.
- Each fact is a row with the label on the left and the value on the right (`space-between`).
- The small flag sits next to the place name.
- All cards must have the button at the same height at the bottom, even if the content differs. Look up `margin-top: auto` and `flex: 1`.

### Step 9: Hover effects

**Goal:** the page feels alive.

Hints (see the style guide for exact values):
- Buttons change color when you hover. Use `transition` so it animates smoothly.
- Cards lift up a little and get a bigger shadow.
- Navigation links change color.

### Step 10: The footer

**Goal:** a white bar with centered gray text. You can do this one alone!

---

## Checklist: am I done?

- [ ] The header has the logo, 4 links and the button, all in one line
- [ ] The hero has the text on the left and 4 tiles on the right
- [ ] The second column of tiles sits lower
- [ ] The 3 stat boxes are equal
- [ ] There are exactly 4 cards per row
- [ ] All cards have the same height and the buttons line up at the bottom
- [ ] The number badges are in the top-left corner of each picture
- [ ] Colors match the style guide
- [ ] Every button and card has a hover effect
- [ ] My page looks like the design when the window is 1440 px wide

## Bonus challenges

1. **CSS variables:** put the main colors in `:root { ... }` and use them everywhere with `var(--name)`. Then change one color and watch the whole page change.
2. Add a `:focus-visible` style to the buttons and links (try pressing the Tab key).
3. Make the number badge change color when you hover over its card.
4. Add a smooth `transition` to every hover effect on the page.

## Stuck?

1. Compare your page to the design. Find the **first** thing that is different. Fix only that.
2. Use Inspect in Chrome to see which styles are really applied.
3. Check for typos: a missing `;` or `}` can break everything after it.
4. Ask your teacher. Good luck!

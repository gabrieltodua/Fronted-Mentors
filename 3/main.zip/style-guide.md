# Style guide

**Font:** `Arial, sans-serif`

## Colors

| Name | Color | Used for |
|---|---|---|
| Dark text | `#0c2d48` | headings, main text, second button text and border |
| Gray-blue text | `#4a6a80` | paragraphs, nav links, number labels |
| Teal | `#0891b2` | logo, main buttons, big numbers |
| Dark blue | `#0c4a6e` | "Join" button, quote section |
| Very dark blue | `#082f49` | footer |
| Light blue | `#e0f4f8` | hero background |
| Circle blue | `#cdeef7` | first story circle |
| Sand | `#fff7e6` | second story background |
| Circle yellow | `#fde9b0` | second story circle |
| Pink-red | `#f43f5e` | the small label "SAILING CLUB" |
| Light text on dark | `#9fd3e6` | quote author, footer text |
| White | `#ffffff` | page, second button, quote text, footer titles |

## Header

| Part | Values |
|---|---|
| Header | padding 22px 120px |
| Logo | 22px, bold |
| Nav | gap 36px |
| Nav links | 16px |
| Join button | padding 10px 24px, radius 20px, 15px bold, no border |

## Hero

| Part | Values |
|---|---|
| Hero | padding 56px top, 120px sides, 64px bottom. Gap 22px |
| Label | 14px, bold |
| Heading | width 900px, 64px, line-height 1.1, centered |
| Paragraph | width 640px, 20px, line-height 1.6, centered |
| Buttons | gap 16px. Each: padding 16px 32px, radius 10px, 16px bold |
| Second button border | 2px solid |
| Sea picture | 1200 x 380px, radius 28px, 14px space above it |

## Numbers

| Part | Values |
|---|---|
| Section | padding 64px 120px |
| Each number block | width 300px, gap 8px |
| Big number | 64px bold |
| Label | 18px |

## Story sections

| Part | Values |
|---|---|
| Section | padding 80px 120px |
| Circle | 400 x 400px, fully round |
| Picture inside | 300 x 300px |
| Text block | width 600px, gap 20px |
| Heading | 42px |
| Paragraph | 18px, line-height 1.6 |
| "Read more" button | padding 16px 32px, radius 10px, 16px bold |

## Quote

| Part | Values |
|---|---|
| Section | padding 90px 120px, gap 20px |
| Quote | 44px, bold, centered |
| Author | 18px |

## Footer

| Part | Values |
|---|---|
| Footer | padding 56px 120px |
| Each column | width 300px, gap 12px |
| Text | 15px, line-height 1.5 |
| First line (title) | 17px, bold, white |
